import threading
import time
import cv2
import turtle
import numpy as np
from sympy import Symbol, solve
from interpreter import InterpreterHelper
import logging
from led_connect import *
import random


def contours_image(img, side=0, mode=0, max_pixel=100, thr=127, debug=10):
    '''
    윤관선 따기 코드
    :param img: 윤곽선을 가져올 이미지
    :param side: 0 = 자동, 1 = 가로, 2 = 세로 / 해당 기준으로 max_pixel을 정의
    :param mode: 0 = 가장 바깥쪽, 1 = 모든 윤곽선 / 선택 모드에 따라 가장 바깥쪽 윤곽선만 검출하거나 모든 윤곽선 검출
    :param max_pixel: 변환될 이미지의 최대 크기를 정의
    :param thr: 윤곽선을 인식할 임계값
    :param debug: 디버그모드
    :return: 윤곽선으로 변환된 numpy 개체
    '''
    logging.basicConfig(level=debug)

    src = cv2.imread(img, cv2.IMREAD_COLOR)
    # src = cv2.imread("robot_noncap.png")
    height, width = src.shape[:2]
    logging.info("원본 {}x{}".format(width, height))

    if side == 0:
        x = Symbol('x')
        equation = max(height, width) * x - max_pixel
        scaler = solve(equation)[0]
        # 방정식을 이용한 스케일링

    elif side == 1:
        x = Symbol('x')
        equation = width * x - max_pixel
        scaler = solve(equation)[0]

    elif side == 2:
        x = Symbol('x')
        equation = height * x - max_pixel
        scaler = solve(equation)[0]

    src = cv2.resize(src, (int(width*scaler), int(height*scaler)), None, 0, 0, cv2.INTER_AREA)
    height, width = src.shape[:2]
    logging.info("스케일 {}x{}".format(width, height))
    # 좌표값 단순화를 위한 스케일링
    # scale_target = 100 일 시, robot_noncap 의 경우 1288 > 184
    # 100 이하로 내리면 형태 나오기 힘듬

    # 이미지 불러오기
    # 하얀 배경 백그라운드만 가능

    src = cv2.flip(src, 0)
    # 그대로 출력하면 뒤집힘

    gray = cv2.cvtColor(src, cv2.COLOR_RGB2GRAY)
    # 검출을 위해 그레이 이미지로 변환

    ret, binary = cv2.threshold(gray, thr, 255, cv2.THRESH_BINARY)
    # 두번째 파라미터(thr)로 임계값을 설정하고 임계값 이하의 값은 전부 하얀색으로 처리

    binary = cv2.bitwise_not(binary)
    # 반전

    # 선택 모드에 따라 가장 바깥쪽 윤곽선만 검출하거나 모든 윤곽선 검출
    if mode == 1:
        contours, hierachy = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    else:
        contours, hierachy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_NONE)

    # 윤곽선 검출
    '''
    현재는 꼭지점만 나오는 SIMPLE 을 사용하였지만 
    구현 시 NONE 으로 사용하여 인덱스 무시하는 방향으로 처리검토
    폴리봇 윤곽처리할 시
    >> CHAIN_APPROX_SIMPLE 184 / CHAIN_APPROX_NONE 340
    '''
    logging.debug("contours = ", contours)
    logging.debug("계층구조 = ", np.shape(contours))

    print(contours)

    # np.save('{}'.format(img.split('.')[0]), contours)

    if debug < 10:
        for i in contours:
            cv2.drawContours(src, [i], -1, (0, 0, 255), 2)
        cv2.imshow("src", src)
        cv2.waitKey(0)
        cv2.destroyAllWindows()
        # 이미지를 보기 위한 코드

    return contours


'''
Example command: movej([0,1.57,-1.57,3.14,-1.57,1.57], a=1.4, v=1.05,
t=0, r=0)
• Example Parameters:
• q = [0,1.57,-1.57,3.14,-1.57,1.57] base is at 0 deg rotation, shoulder is at 90 deg
rotation, elbow is at -90 deg rotation, wrist 1 is at 180 deg rotation, wrist 2 is at -90 deg
rotation, wrist 3 is at 90 deg rotation. Note: joint positions (q can also be specified as a
pose, then inverse kinematics is used to calculate the corresponding joint positions)
• a = 1.4 → acceleration is 1.4 rad/s/s
• v = 1.05 → velocity is 1.05 rad/s
• t = 0 the time (seconds) to make move is not specified. If it were specified the
command would ignore the a and v values.
• r = 0 → the blend radius is zero meters.
'''


def draw_line_inside(ip, ser, led_num, rgb, contours,  s=1, defalut_axis="[d2r(90), d2r(0), d2r(-90), d2r(-90), d2r(-90), d2r(0)]", trans_axis="p[0, 0, 0, 0, 0, 0]", a=1.2, v=0.25, t=0, r=0, debug=10):
    '''
    :param ip: 그림을 그릴 로봇의 ip
    :param ser: led server
    :param led_num: led client num
    :param rgb: rbg(list, tuple)
    :param contours: 윤곽선
    :param s: 이미지 배수()
    :param defalut_axis: 시작점(x, y 좌표의 0, 0/origin)
    :param trans_axis: 상대좌표변환 / 축을 돌릴 때 사용
    :param a: 로봇 가속도
    :param v: 로봇 속도
    :param t: 기억안나는데 안건드리는거 추천
    :param r: 반지름 혼합
    :param debug: 디버그 모드 사용 시 터틀로 그림 / led 로 인해 오류 있을 수 있음
    :return:
    '''

    logging.basicConfig(level=debug)

    # UR 열어주기
    if ip:
        ur_itp = InterpreterHelper(ip)
        if ur_itp.connect():
            logging.info("{} 연결완료".format(ip))
        if ur_itp.execute_command("clear_interpreter()"):
            logging.debug("인터프리터 버퍼 초기화")

    # print('open : ',ser.isOpen())
    if ser:
        if(ser.isOpen()==False):
            ser = serial.Serial(port="/dev/cu.usbserial-024A0D88", baudrate=115200, timeout=0.1)  # 포트 연결

        ser.write(bytes(set_packet(led_num, 0, rgb)))

    if debug < 10:
        turtle.penup()

    # while True:
    for cons_list in contours:
        cons_list = np.concatenate(cons_list).tolist()  # 중첩 리스트 벗기기
        logging.debug(cons_list)
        logging.debug(len(cons_list))
        if ip:
            last_command_id = ur_itp.get_last_interpreted_id()
        cons_map = []
        for x, y in cons_list:
            cons_map.append([x, y])

            if ip:
                command_line = "movej(pose_trans({trans_axis}, pose_add({defalut_axis}, \
                p[{x:.3f}, 0,{z:.3f}, 0, 2.222, -2.222])), a = {a}, v = {v}, t={t}, r={r})"\
                .format(trans_axis=trans_axis, defalut_axis=defalut_axis, x=x / 1000 * s, z=y / 1000 * s, a=a, v=v, t=t, r=r)
                command_id = ur_itp.execute_command(command_line)

                # 켜기 동작 추가
                # set_packet(0xXY : X = 보드번호 Y = LED번호, uint8 : 밝기, [n, n, n] : RGB 색상, uint8 : style, uint8 : 지속시간)
                if ur_itp.get_last_cleared_id()+1 < ur_itp.get_last_executed_id():
                    if ser:
                        ser.write(bytes(set_packet(led_num, 255, rgb)))
                while command_id-ur_itp.get_last_executed_id() > 100:
                    logging.debug("Last executed id {}/{}".format(ur_itp.get_last_executed_id(), command_id))
                    time.sleep(0.01)
                logging.debug(command_id)
                time.sleep(0.01)
                while command_id != ur_itp.get_last_executed_id():
                    time.sleep(0.05)
                    if ur_itp.execute_command("clear_interpreter()"):
                        logging.debug("인터프리터 버퍼 초기화")
                    if ser:
                        ser.write(bytes(set_packet(led_num, 0, rgb)))
                    last_command_id = command_id
            # 끄기 동작 추가
            if debug < 10:
                turtle.goto(x * s, y * s)
                turtle.pendown()


        if debug < 10:
            turtle.penup()
        logging.info(cons_map)
    if ser:
        ser.write(bytes(set_packet(led_num, 0, rgb)))


def go_home(ip, debug=10):
    logging.basicConfig(level=debug)
    ur_itp = InterpreterHelper(ip)
    if ur_itp.connect():
        logging.info("{} 연결완료".format(ip))
    if ur_itp.execute_command("clear_interpreter()"):
        logging.debug("인터프리터 버퍼 초기화")
    ur_itp.execute_command("movej([d2r(0), d2r(-90), d2r(0), d2r(-90), d2r(0), d2r(0)])")         # stay




# 함수 시작
#
py_serial = 0
# py_serial = serial.Serial(port="/dev/cu.usbmodem54240268991", baudrate=115200, timeout=0.1)    # 포트 연결
# py_serial = serial.Serial(port="/dev/cu.usbserial-024A0D88", baudrate=115200, timeout=0.1)    # 포트 연결
# readUntilString(py_serial)

time.sleep(1)
# led_num, rgb_list, brightness, style, wait
#
# trans = set_packet(0x41, [255, 43, 123], 100, STYLE.chase.value, 100)
# send_data = py_serial.write(bytes(trans))



ip0 = "192.168.213.72"
# ip1 = "192.168.213.73"
ip1 = 0
ip2 = "192.168.213.74"
ip3 = "192.168.213.75"
ip4 = "192.168.213.76"
ip5 = "192.168.213.77"
ip6 = "192.168.213.78"
ip7 = "192.168.213.79"
ip8 = "192.168.213.80"

ip_list = [ip0, ip1, ip2, ip3, ip4, ip5, ip6, ip7, ip8]




img0 = "image/polybot.jpg"
img1 = "image/I.jpeg"
img2 = "image/heart.jpeg"
img3 = "image/ROBOT.jpeg"
img4 = "image/We_Draw_the_Future.jpeg"
img5 = "image/wdtf.jpeg"
img6 = "image/WE.jpeg"
img7 = "image/Draw_the.jpeg"
img8 = "image/Future.jpeg"
img9 = "image/2KNG.jpeg"
img10 = "image/k1.jpg"
img11 = "image/k2.jpg"
img12 = "image/k3_n2.jpg"
img13 = "image/k4_n5.jpg"
img14 = "image/k5.jpg"
# contours_image(img6, 2, 0, 150)
# contours_image(img7, 2, 0, 150)
# contours_image(img8, 2, 0, 150)

# def contours_image(img, side=0, mode=0, max_pixel=100, thr=127, debug=0):
# def draw_line_inside(ip, ser, led_num, rgb ,contours,  s=1, defalut_axis="[d2r(90), d2r(0), d2r(-90), d2r(-90), d2r(-90), d2r(0)]", trans_axis="p[0, 0, 0, 0, 0, 0]", a=1.2, v=0.25, t=0, r=0, debug=20):

# go_home(ip8)


# py_serial.write(bytes(set_packet(0x15, 0, [0, 0, 0], 0)))

draw_line_inside(ip1, py_serial, 0x15, [255, 80, 150], contours_image(img10, 0, 1, 150, 150), 1.5, "p[0.1, -0.4, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 2, 0.5, 0, 0.003, 0)
draw_line_inside(ip1, py_serial, 0x15, [100, 100, 211], contours_image(img11, 0, 1, 150, 150), 1.5, "p[0.1, -0.4, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 2, 0.5, 0, 0.003, 0)
draw_line_inside(ip1, py_serial, 0x15, [50, 0, 200], contours_image(img12, 0, 1, 150, 150), 1.5, "p[0.1, -0.4, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 2, 0.5, 0, 0.003, 0)
draw_line_inside(ip1, py_serial, 0x15, [50, 50, 207], contours_image(img13, 0, 1, 150, 150), 1.5, "p[0.1, -0.4, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 2, 0.5, 0, 0.003, 0)
draw_line_inside(ip1, py_serial, 0x15, [100, 0, 255], contours_image(img14, 0, 1, 150, 150), 1.5, "p[0.1, -0.4, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 2, 0.5, 0, 0.003, 0)


# py_serial.write(bytes(set_packet(0x15, 0, [0, 0, 0], 0)))


#
# t1 = threading.Thread(target=draw_line_inside, args=(ip3, contours_image(img1), 1.5, "p[0.3, -0.5, 0.15, 0, 0, 0)]", "p[0, 0, 0, 0, 0, d2r(0)", 2.5, 1.0, 0, 0.003))
# t2 = threading.Thread(target=draw_line_inside, args=(ip3, contours_image(img1), 1.5, "p[0.3, -0.5, 0.15, 0, 0, 0)]", "p[0, 0, 0, 0, 0, d2r(0)", 2.5, 1.0, 0, 0.003))
#

# draw_line_inside(ip_list[3], contours_image(img5, 0, 100, 150), 1.5, "p[0.13, -0.5, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003)
#
#
# for i in range(0x40, 0x48):
#     py_serial.write(bytes(set_packet(i, 30, [0, 255, 0])))
#     # time.sleep(0.1)
#     # py_serial.write(bytes(set_packet(i, 0)))
#     # time.sleep(0.15)
# time.sleep(0.2)
# py_serial.write(bytes(set_packet(i, 0)))
# time.sleep(0.3)
#
# for i in range(0x40, 0x48):
#     py_serial.write(bytes(set_packet(i, 10, [0, 255, 0])))
# time.sleep(0.1)
#
# py_serial.write(bytes(set_packet(i, 0)))
#
# time.sleep(1)
#
# for i in range(0x40, 0x48):
#     py_serial.write(bytes(set_packet(i, 10, [0, 255, 0])))
#     time.sleep(0.1)
#     py_serial.write(bytes(set_packet(i, 0)))
#     time.sleep(0.15)
#
# time.sleep(1)
#
# for i in range(0x40, 0x48):
#     py_serial.write(bytes(set_packet(i, 10, [0, 255, 0])))
#     time.sleep(0.1)
#     # py_serial.write(bytes(set_packet(i, 0)))
#     time.sleep(0.15)
#
# time.sleep(1)
#
# for i in range(0x40, 0x48):
#     # py_serial.write(bytes(set_packet(i, 100, [0, 255, 0])))
#     time.sleep(0.1)
#     py_serial.write(bytes(set_packet(i, 1, [0, 0, 0])))
#     time.sleep(0.15)

# contours_image(img6, 0, 100, 150)
def set_rainbow_color(ser, address):
    rainbow_list = [[255, 0, 0],  # Red
                    [255, 140, 0],  # Orange
                    [255, 255, 0],  # Yellow
                    [0, 255, 0],  # Green
                    [0, 0, 255],  # Blue
                    [18, 0, 255],  # Indigo
                    [255, 0, 255],  # Purple
                    [255, 255, 255]]

    for led_number in range(7):
        trans = set_packet(address + led_number, 50, rainbow_list[led_number], STYLE.oneColor.value, 10)
        send_data = ser.write(bytes(trans))
        time.sleep(0.02)

def draw_rainbow(ip, ser, debug = 10):
    logging.basicConfig(level=debug)
    ur_itp = InterpreterHelper(ip)
    if ur_itp.connect():
        logging.info("{} 연결완료".format(ip))
    if ur_itp.execute_command("clear_interpreter()"):
        logging.debug("인터프리터 버퍼 초기화")
    ur_itp.execute_command("movej([d2r(0), d2r(-90), d2r(90), d2r(-90), d2r(0), d2r(0)])")
    set_rainbow_color(ser, 0x50)
    ur_itp.execute_command("movej([d2r(0), d2r(-90), d2r(90), d2r(-90), d2r(180), d2r(0)])")
    command_id = ur_itp.execute_command("movej([d2r(0), d2r(-90), d2r(90), d2r(-90), d2r(0), d2r(0)])")
    while command_id != ur_itp.get_last_executed_id():
        time.sleep(0.05)
    ser.write(bytes(set_packet(0x50,  0, [0, 0, 0], STYLE.oneColor.value, 10)))
#
# draw_line_inside(ip1, contours_image(img0, 2, 0, 200))
# draw_line_inside(ip1, contours_image(img1, 2, 1, 100))
# draw_line_inside(ip1, contours_image(img2, 2, 1, 100))
# draw_line_inside(ip1, contours_image(img3, 2, 0, 100))
# draw_line_inside(ip1, contours_image(img5, 2, 0, 200))
# -0.15
#
#
# #

# 220601
#
#
# t2 = threading.Thread(target=draw_line_side, args=(ip1, py_serial, 0x15, [0, 255, 255], contours_image(img0, 2, 0, 70), 2.4, "p[-0.3, 0.3, 0.32, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 1, 0.5, 0, 0.003))
# t2.start()
# t2 = threading.Thread(target=draw_line_side, args=(ip1, py_serial, 0x15, [0, 255, 255], contours_image(img0, 2, 0, 70), 2.4, "p[-0.3, 0.3, 0.32, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(0)]", 1, 0.5, 0, 0.003))
# t2.start()
# t3 = threading.Thread(target=draw_line_inside, args=(ip8, py_serial, 0x30, [22, 133, 248], contours_image(img6, 2, 0, 60), 1.2, "p[-0.4, -0.4, 0.4, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(270)]", 1, 0.5, 0, 0.003))
# t3.start()
# t1 = threading.Thread(target=draw_line_inside, args=(ip0, py_serial, 0x20, [100, 255, 255], contours_image(img1, 2, 1, 50), 2.2, "p[-0.4, -0.5, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(180)]", 1, 0.5, 0, 0.003))
# t1.start()
# t1.join()
# t1 = threading.Thread(target=draw_line_inside, args=(ip0, py_serial, 0x20, [255, 43, 123], contours_image(img2, 2, 0, 50), 2.2, "p[-0.32, -0.55, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(180)]", 1, 0.5, 0, 0.003))
# t1.start()
# t1.join()
# t1 = threading.Thread(target=draw_line_inside, args=(ip0, py_serial, 0x20, [100, 255, 255], contours_image(img3, 2, 0, 50), 2.2, "p[-0.17, -0.55, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(180)]", 1, 0.5, 0, 0.003))
# t1.start()
# t3.join()
# t3 = threading.Thread(target=draw_line_inside, args=(ip8, py_serial, 0x30, [20, 255, 30], contours_image(img7, 2, 0, 60), 1.2, "p[-0.4, -0.4, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(270)]", 1, 0.5, 0, 0.003))
# t3.start()
# t3.join()
# t3 = threading.Thread(target=draw_line_inside, args=(ip8, py_serial, 0x30, [245, 39, 137], contours_image(img8, 2, 0, 60), 1.2, "p[-0.4, -0.4, 0.2, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(270)]", 1, 0.5, 0, 0.003))
# t3.start()
# t2.join()
# t2 = threading.Thread(target=draw_line_inside, args=(ip1, py_serial, 0x10, [255, 255, 255], contours_image(img9, 2, 0, 50), 1.5, "p[0, -0.5, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 1, 0.5, 0, 0.003))
# t2.start()
#


# t2 = threading.Thread(target=draw_line_inside, args=(ip_list[1], py_serial, 0x20, [0, 255, 0], contours_image(img2, 1, 100, 150), 1.9, "p[0.1, -0.4, 0.5, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003))


# t2 = threading.Thread(target=draw_line_inside, args=(ip_list[1], contours_image(img2, 1, 100, 150), 1.9, "p[0.1, -0.4, 0.5, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003))
# t2.start()
#
# go_home(ip2)

# go_home(ip0)
# for i in range(1, 4):
#     go_home(ip_list[i])
#     go_home(ip_list[-i])
#

# draw_rainbow(ip7, py_serial)

# contours_image(img5, 0, 0, 500)



#
# t1 = threading.Thread(target=draw_line_inside, args=(ip_list[0], py_serial, 0x40, [0, 255, 255], contours_image(img1, 0, 100, 150), 1.7, "p[-0.1, -0.5, 0.35, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(180)]", 3, 1.5, 0, 0.003))
# t1.start()
# t2 = threading.Thread(target=draw_line_inside, args=(ip_list[1], py_serial, 0x20, [0, 255, 0], contours_image(img2, 1, 100, 150), 1.9, "p[0.1, -0.4, 0.5, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003))
# t2.start()
# t3 = threading.Thread(target=draw_line_inside, args=(ip_list[8], py_serial, 0x30, [0, 255, 0], contours_image(img6, 1, 100, 150), 2.1, "p[-0.35, -0.4, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(-90)]", 3, 1.5, 0, 0.003))
# t3.start()
# t4 = threading.Thread(target=draw_line_inside, args=(ip_list[2], py_serial, 0x15, [255, 43, 123], contours_image(img7, 0, 100, 150), 1.5, "p[0.1, -0.4, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003))
# t4.start()
#
# t2.join()
# t5 = threading.Thread(target=draw_line_inside, args=(ip_list[1], py_serial, 0x20, [0, 0, 255], contours_image(img3, 1, 100, 150), 2.1, "p[0.1, -0.4, 0.3, 0, 0, d2r(0)]", "p[0, 0, 0, 0, 0, d2r(90)]", 3, 1.5, 0, 0.003))
# t5.start()

# py_serial.write(bytes(set_packet(0x30, 0)))
# #
# time.sleep(5)

# pa_r(ip5)


# pa_f(ip0)
# time.sleep(1)
#
# for i in range(1, 4):
#     pa_l(ip_list[i])
#     pa_r(ip_list[-i])
#     time.sleep(3)

# # time.sleep(7)
#
# f_clear(ip0)
# for i in range(1, 4):
#     l_clear(ip_list[i])
#     r_clear(ip_list[-i])
#
# go_home(ip0)
# for i in range(1, 4):
#     go_home(ip_list[i])
#     go_home(ip_list[-i])

# for i in range(1, 4):
#     pa_l(ip_list[i])
#     pa_r(ip_list[-i])
#     time.sleep(1)
# for i in range(1, 4):
#     threading.Thread(target=draw_line_inside, args=(ip_list[i], contours_image(img1, 1, 150), 1.5, "p[-0.1, 0.3, 0, 0, 0, d2r(90)]", 2.5, 1.0, 0, 0.003)).start()
#
# for i in range(8, 4, -1):
#     pa_r(ip_list[i])
#     # threading.Thread(target=pa_r, args=(ip_list[i],)).start()
#     # threading.Thread(target=draw_line_inside, args=(ip_list[i], contours_image(img1, 1, 150), 1.5, "p[-0.1, 0.3, 0.15, 0, 0, d2r(-90)]", 2.5, 1.0, 0, 0.003)).start()

# t1.start()
# t2.start()
# draw_line_inside(ip1, contours_image("white_background_poly.jpg"), s=1.5, trans_axis ="p[0, 0, 0, 0, 0, d2r(0)]", a=2.5, v=1.0, t=0, r=0.003)



py_serial.write(bytes(set_packet(0x15, 0, [0, 0, 0], 0)))


# change WiFi
# trans = set_packet(255, 255, [0, 0, 0], 0, 1, 20)
# send_data = py_serial.write(bytes(trans))

# serial_receive_callback(py_serial, send_data)


while True:
    time.sleep(0.1)

py_serial.close()