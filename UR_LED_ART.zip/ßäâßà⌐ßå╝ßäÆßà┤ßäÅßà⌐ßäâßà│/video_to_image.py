import cv2
import os


# print(os.listdir("./video"))
# for i in os.listdir("./video/"):
    # src = './video/{}'.format(i)
src = './video_new/C0035.MP4'
print(src)
src_dir, src_name = os.path.split(src)
src_name, src_ext = os.path.splitext(src_name)
video_src = cv2.VideoCapture(src)
length = int(video_src.get(cv2.CAP_PROP_FRAME_COUNT))
width = int(video_src.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video_src.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = video_src.get(cv2.CAP_PROP_FPS)

print("length :", length)
print("width :", width)
print("height :", height)
print("fps :", fps)

success, image = video_src.read()

shutter_speed = 1/30

if not os.path.exists(os.path.join(src_dir, src_name)):
    image_dir = os.path.join(src_dir, src_name)
    os.mkdir(image_dir)
    count = 0

    while video_src.isOpened():
        hasFrame, img_frame = video_src.read()
        # if int(video_src.get(1)) % int(fps*shutter_speed) == 0:
        if not hasFrame:
            print("end")
            break
        cv2.imwrite(os.path.join(image_dir, "{0:05d}.jpg".format(count)), img_frame)
        print("save image {0:5d}.jpg".format(count))
        count += 1

    print("work_end")


